//
//  Employee.swift
//  Service-hit-swiftui
//
//  Created by Akash Soni on 02/09/19.
//  Copyright © 2019 Akash Soni. All rights reserved.
//

//   let employee = try? newJSONDecoder().decode(Employee.self, from: jsonData)

import Foundation

// MARK: - EmployeeElement

struct EmployeeElement: Codable {
    let id, employeeName, employeeSalary, employeeAge: String
    let profileImage: String

    enum CodingKeys: String, CodingKey {
        case id
        case employeeName = "employee_name"
        case employeeSalary = "employee_salary"
        case employeeAge = "employee_age"
        case profileImage = "profile_image"
    }
}

typealias Employee = [EmployeeElement]
