//
//  ContentView.swift
//  Service-hit-swiftui
//
//  Created by Akash Soni on 02/09/19.
//  Copyright © 2019 Akash Soni. All rights reserved.
//

import SwiftUI
import Combine


class NetworkManager:ObservableObject{
    var didChange = PassthroughSubject<NetworkManager,Never>()
    
    @Published var employee = Employee(){
        didSet{
            didChange.send(self)
        }
    }
    init(){
        callApi()
    }

    func callApi(){
        let url = URL(string: "http://dummy.restapiexample.com/api/v1/employees")
        URLSession.shared.dataTask(with: url!) { (servicedata, _, _) in
            guard let data = servicedata else { return }
            let decoder = JSONDecoder()
            let employee = try! decoder.decode(Employee.self, from: data)
            DispatchQueue.main.async {
                self.employee = employee
            }
        }.resume()
        
    }
}

struct ContentView: View {
    @ObservedObject var networkManager = NetworkManager()
    var body: some View {
        NavigationView{
            List(
                self.networkManager.employee
            , id: \.id){ (emp) in
                //name, salary, age, image
                NavigationLink(destination: DetailContentView(name: emp.employeeName)) {
                    HStack{
                        Image("image")
                        VStack{
                        Text(emp.employeeName)
                        Text("Age :" + emp.employeeAge)
                        }
                        Spacer()
                        Text("$ " + emp.employeeSalary)
                    }
                }
                
            }
            .navigationBarTitle("Employee")
        }
    }
}
struct DetailContentView: View {
    var name:String
    var body: some View {
    VStack{
        Image("img")
            .resizable()
            .frame(width: nil, height: 300.0)
            
        Text(name).font(.largeTitle).foregroundColor(.black)
        Spacer()
    }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
