//
//  LocationModel.swift
//  MyFirstMapTODO
//
//  Created by JASI on 14/01/20.
//  Copyright © 2020 lambton. All rights reserved.
//

import Foundation

struct LocationModel {
    
    var locName : String ;
    var locLat : Double ;
    var locLong : Double ;
    var locSubtitle : String ;
    
    init ( name : String , lat : Double , long : Double , subtitle : String ) {
        self.locName = name
        self.locLat = lat
        self.locLong = long
        self.locSubtitle = subtitle
    }
    
}
