//
//  LocationTableViewCell.swift
//  MyFirstMapTODO
//
//  Created by JASI on 14/01/20.
//  Copyright © 2020 lambton. All rights reserved.
//

import UIKit

class LocationTableViewCell: UITableViewCell {

    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var latLabel: UILabel!
    @IBOutlet weak var longLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func updateCell ( loc : LocationEntity ) {
        nameLabel.text = loc.name
        latLabel.text = String(loc.latitude)
        longLabel.text = String(loc.longitude)
        subtitleLabel.text = loc.subtitle
    }
    func updateCell ( loc : TPerson ) {
        nameLabel.text = loc.name
        latLabel.text = String(loc.lattiude)
        longLabel.text = String(loc.longitude)
        subtitleLabel.text = loc.country
    }

}
