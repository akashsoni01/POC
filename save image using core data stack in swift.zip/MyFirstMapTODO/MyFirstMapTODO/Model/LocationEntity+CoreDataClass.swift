//
//  LocationEntity+CoreDataClass.swift
//  MyFirstMapTODO
//
//  Created by JASI on 16/01/20.
//  Copyright © 2020 lambton. All rights reserved.
//
//

import Foundation
import CoreData

@objc(LocationEntity)
public class LocationEntity: NSManagedObject {

}
