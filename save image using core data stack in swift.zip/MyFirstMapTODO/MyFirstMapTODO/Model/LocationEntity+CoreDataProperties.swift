//
//  LocationEntity+CoreDataProperties.swift
//  MyFirstMapTODO
//
//  Created by JASI on 16/01/20.
//  Copyright © 2020 lambton. All rights reserved.
//
//

import Foundation
import CoreData


extension LocationEntity {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<LocationEntity> {
        return NSFetchRequest<LocationEntity>(entityName: "LocationEntity")
    }

    @NSManaged public var latitude: Double
    @NSManaged public var longitude: Double
    @NSManaged public var name: String?
    @NSManaged public var subtitle: String?

}
