//
//  BookMarksVC.swift
//  MyFirstMapTODO
//
//  Created by JASI on 14/01/20.
//  Copyright © 2020 lambton. All rights reserved.
//

import UIKit
import CoreData

class BookMarksVC: UIViewController , UITableViewDataSource , UITableViewDelegate {
    
    var managedContext: NSManagedObjectContext!
    
    var copyOfCoreList = [LocationEntity]()
    var personListArray = [TPerson]()

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return personListArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "LocationTableViewCell") as? LocationTableViewCell {
            let locationCell = personListArray[indexPath.row]
            cell.updateCell(loc: locationCell)
            return cell
        } else {
            return LocationTableViewCell()
        }
    }
    
    
    @IBOutlet weak var tableView: UITableView!
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        managedContext = ViewController.managedContext
//        let request:NSFetchRequest<LocationEntity> = LocationEntity.fetchRequest()
//        let results = try? managedContext.fetch(request)
//        if let resultarray = results{
//            self.copyOfCoreList = resultarray
//        }
        let request:NSFetchRequest<TPerson> = TPerson.fetchRequest()
        let results = try? managedContext.fetch(request)
        if let resultarray = results{
            self.personListArray = resultarray
        }
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let story = UIStoryboard(name: "Main", bundle: nil)
//        var selectedLocation : LocationModel
//        let vc = story.instantiateViewController(identifier: "AddOrEditLocationVC") as! AddOrEditLocationVC
//        vc.selectedLocation = ViewController.locationList[indexPath.row]
//        vc.selectedLocationIndex = indexPath.row
//        self.navigationController?.pushViewController(vc, animated: true)
        
        let story = UIStoryboard(name: "Main", bundle: nil)
        let vc = story.instantiateViewController(withIdentifier: "AddOrEditLocationVC") as! AddOrEditLocationVC
//        vc.selectedPerson = personListArray[indexPath.row]
        vc.selectedPerson = personListArray[indexPath.row]
        vc.managedContext = ViewController.managedContext
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
}
