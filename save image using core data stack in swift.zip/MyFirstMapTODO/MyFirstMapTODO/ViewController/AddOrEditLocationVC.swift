//
//  AddOrEditLocationVC.swift
//  MyFirstMapTODO
//
//  Created by JASI on 14/01/20.
//  Copyright © 2020 lambton. All rights reserved.
//

import UIKit
import CoreData

class AddOrEditLocationVC: UIViewController {
    
//    var selectedLocEntity : LocationEntity!
    var selectedPerson : TPerson!

    var managedContext: NSManagedObjectContext!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtLat: UITextField!
    @IBOutlet weak var txtLong: UITextField!
    @IBOutlet weak var txtSubtitle: UITextField!
    @IBOutlet weak var lblError: UILabel!
    @IBOutlet weak var btnDelete: UIButton!
    @IBOutlet weak var imageViewBtn: UIButton!
    
    var selectedLocation : LocationModel!
    var selectedLocationIndex : Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        managedContext = ViewController.managedContext
//        if selectedLocEntity != nil {
//            txtName.text = selectedLocEntity.name
//            txtLat.text = String(selectedLocEntity.latitude)
//            txtLong.text = String(selectedLocEntity.longitude)
//            txtSubtitle.text = String(selectedLocEntity.subtitle ?? "")
//            btnDelete.isHidden = false
//
//
//            if let location = person { title = "Edit Location"
//            // New code block
//            if location.hasPhoto {
//            if let theImage = location.photoImage {
//                    show(image: theImage)
//                  }
//            }
//                // End of new code
//            }
//        }
        if selectedPerson != nil {
            txtName.text = selectedPerson.country
            txtLat.text = String(selectedPerson.lattiude)
            txtLong.text = String(selectedPerson.longitude)
            txtSubtitle.text = selectedPerson.name
            btnDelete.isHidden = false
            
            
            if let location = selectedPerson { title = "Edit Location"
            // New code block
            if location.hasPhoto {
            if let theImage = location.photoImage {
                    show(image: theImage)
                  }
            }
                // End of new code
            }
        }else{
            selectedPerson = TPerson(context: managedContext)
        }
        
    }
    
    
    @IBAction func deleteBtnTapped(_ sender: Any) {
//        managedContext.delete(selectedLocEntity)
        managedContext.delete(selectedPerson)
        selectedPerson.removePhotoFile()
        try? managedContext.save()
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func saveBtnTapped(_ sender: Any) {
//        if selectedLocEntity == nil{
//            let location = LocationEntity(context: managedContext)
//            location.name =    txtName.text ?? ""
//            location.subtitle = txtSubtitle.text
//            location.latitude = Double(txtLat.text ?? "")!
//            location.longitude = Double(txtLong.text ?? "")!
//        }else{
//            self.selectedLocEntity.name =     txtName.text
//            self.selectedLocEntity.subtitle = txtSubtitle.text
//            self.selectedLocEntity.latitude = Double(txtLat.text ?? "")!
//            self.selectedLocEntity.longitude = Double(txtLong.text ?? "")!
//        }
        
        
        if selectedPerson == nil{
            selectedPerson.country =    txtName.text ?? ""
            selectedPerson.name = txtSubtitle.text
            selectedPerson.lattiude = Double(txtLat.text ?? "")!
            selectedPerson.longitude = Double(txtLong.text ?? "")!
        }else{
            self.selectedPerson.country = txtName.text
            self.selectedPerson.name = txtSubtitle.text
            self.selectedPerson.lattiude = Double(txtLat.text ?? "")!
            self.selectedPerson.longitude = Double(txtLong.text ?? "")!
        }
        try? managedContext.save()
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func picAProfile(_ sender: Any) {
        takePhotoWithCamera()
    }
    func show(image: UIImage) {
        imageViewBtn.setTitle("", for: .normal)
        imageViewBtn.setBackgroundImage(image, for: .normal)
        imageViewBtn.frame = CGRect(x: 10, y: 10, width: 260,height: 260)
        
        
        // Save image
        // 1
        if !selectedPerson.hasPhoto {
            selectedPerson.photoID = TPerson.nextPhotoID() as NSNumber
        }
        // 2
        if let data = image.jpegData(compressionQuality: 0.5) { // 33 3
            do
            {
                try data.write(to: selectedPerson.photoURL, options: .atomic)
            } catch {
                print("Error writing file: \(error)")
            }
        }
    }
    
}
extension AddOrEditLocationVC:
    UIImagePickerControllerDelegate,
    UINavigationControllerDelegate {

  func takePhotoWithCamera() {
    let imagePicker = UIImagePickerController()
    imagePicker.sourceType = .photoLibrary
    imagePicker.delegate = self
    imagePicker.allowsEditing = true
    present(imagePicker, animated: true, completion: nil)
  }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.editedImage] as? UIImage{
              show(image: image)

          }
        dismiss(animated: true, completion: nil)

    }

    func imagePickerControllerDidCancel(_ picker:
                          UIImagePickerController) {
        
      dismiss(animated: true, completion: nil)
    }

}

