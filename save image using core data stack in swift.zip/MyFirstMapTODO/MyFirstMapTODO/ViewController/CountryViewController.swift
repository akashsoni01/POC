//
//  CountryViewController.swift
//  MyFirstMapTODO
//
//  Created by AkashBuzzyears on 1/24/20.
//  Copyright © 2020 lambton. All rights reserved.
//

import UIKit
class CountryViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var delegate:CountryViewControllerProtocol!
    @IBOutlet weak var tableview:UITableView!
    var selectedCountry = ""
    var countries = ["India","pak","nepal","bhutan","Canada"]
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return countries.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = countries[indexPath.row]
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath)
        if cell?.accessoryType == .none{
            cell?.accessoryType = .checkmark
            cell?.textLabel?.textColor = .red
            self.selectedCountry = countries[indexPath.row]
        }else{
            cell?.accessoryType = .none
            cell?.textLabel?.textColor = .black
            self.selectedCountry = ""

        }

    }
    
    @IBAction func doneButtonClicked(_ sender: UIBarButtonItem) {
        delegate?.didFinishSelectCountry(name: selectedCountry)
    }
    
}
protocol CountryViewControllerProtocol {
    func didFinishSelectCountry(name:String);
}
