//
//  ViewController.swift
//  MyFirstMapTODO
//
//  Created by JASI on 13/01/20.
//  Copyright © 2020 lambton. All rights reserved.
//

import UIKit
import MapKit
import CoreData

class ViewController: UIViewController,CLLocationManagerDelegate , MKMapViewDelegate , UITableViewDataSource , UITableViewDelegate  {
    var selectedAnnotation: MKPointAnnotation?
    var index : Int!
    var selectedPinView: MKAnnotation!
    var filteredPersonLocationList = [TPerson]()
    var personLocationList = [TPerson]()
    static var managedContext: NSManagedObjectContext!
    static var locationList = [LocationModel]()
    //    var coreList = [LocationEntity]()
    //    var coreObj : LocationEntity!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var segment: UISegmentedControl!
    @IBOutlet weak var searchBar: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        tableView.delegate = self
        tableView.dataSource = self
        tableView.isHidden = true
        mapView.isHidden = false
        self.view.layoutIfNeeded()
        
        //to remove table footer seprator
        tableView.tableFooterView = UIView()
        
    }
    override func viewDidAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        
        //managedContext = ViewController.managedContext
        //todo
        //        let request:NSFetchRequest<LocationEntity> = LocationEntity.fetchRequest()
        //        let results = try? ViewController.managedContext.fetch(request)
        //        if let resultarray = results{
        //            self.coreList = resultarray
        //        }
        //        tableView.reloadData()
        //        print("Map will appear now!")
        //        mapView.removeAnnotations(mapView.annotations.filter { $0 !== mapView.userLocation })
        //
        //        for index in 0..<coreList.count {
        //            let loc = coreList[index]
        //            let artwork = Artwork(title: loc.name ?? "",
        //                                  locationName:"\(loc.subtitle?.description)",
        //                discipline: "Sculpture",
        //                coordinate: CLLocationCoordinate2D(latitude: loc.latitude, longitude: loc.longitude), id: index)
        //            mapView.addAnnotation(artwork)
        //        }
        //
        
        let request:NSFetchRequest<TPerson> = TPerson.fetchRequest()
        let results = try? ViewController.managedContext.fetch(request)
        if let resultarray = results{
            self.filteredPersonLocationList = resultarray
            self.personLocationList = resultarray
        }
        tableView.reloadData()
        print("Map will appear now!")
        mapView.removeAnnotations(mapView.annotations.filter { $0 !== mapView.userLocation })
        
        for index in 0..<filteredPersonLocationList.count {
            let loc = filteredPersonLocationList[index]
            let artwork = Artwork(title: loc.name ?? "",
                                  locationName:"\(loc.country ?? "")",
                discipline: "Sculpture",
                coordinate: CLLocationCoordinate2D(latitude: loc.lattiude, longitude: loc.longitude), id: index)
            mapView.addAnnotation(artwork)
        }
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return filteredPersonLocationList.count == 0 ? "No Location Found" : ""
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredPersonLocationList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "LocationTableViewCell") as? LocationTableViewCell {
            let locationCell = filteredPersonLocationList[indexPath.row]
            cell.updateCell(loc: locationCell)
            return cell
        } else {
            return LocationTableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let vc = story.instantiateViewController(withIdentifier: "AddOrEditLocationVC") as! AddOrEditLocationVC
        vc.selectedPerson = filteredPersonLocationList[indexPath.row]
        vc.managedContext = ViewController.managedContext
        self.navigationController?.pushViewController(vc, animated: true)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    func addPin(locName : String, locLat : Double , locLong : Double , locSubtitle : String) {
        let annotation = MKPointAnnotation()
        let centerCoordinate = CLLocationCoordinate2D(latitude: locLat, longitude:locLong)
        annotation.coordinate = centerCoordinate
        annotation.title = locName + " - " + locSubtitle.description
        mapView.addAnnotation(annotation)
    }
    
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        let annotation = view.annotation
        selectedPinView = annotation
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        self.view.layoutIfNeeded()
        
        print("loading map view")
        if !(annotation is MKUserLocation) {
            let pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: String(annotation.hash))
            
            
            let rightButton = UIButton(type: .infoDark)
            rightButton.tag = annotation.hash
            rightButton.addTarget(self, action: #selector(deleteBtnPressed), for: .touchDown)
            pinView.animatesDrop = true
            pinView.canShowCallout = true
            pinView.rightCalloutAccessoryView = rightButton
            
            //            let leftButton = UIButton(type: .close)
            //            leftButton.tag = annotation.hash
            //            leftButton.addTarget(self, action: #selector(deleteBtnPressed), for: .touchDown)
            //            pinView.animatesDrop = true
            //            pinView.canShowCallout = true
            //            pinView.leftCalloutAccessoryView = leftButton
            
            return pinView
        }
        else {
            return nil
        }
    }
    
    
    @IBAction func addButtonTapped(_ sender: Any) {
        //AddOrEditLocationVC
        let story = UIStoryboard(name: "Main", bundle: nil)
        let vc = story.instantiateViewController(withIdentifier: "AddOrEditLocationVC") as! AddOrEditLocationVC
        vc.managedContext = ViewController.managedContext
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func segmentClicked(_ sender: Any) {
        switch segment.selectedSegmentIndex
        {
        case 0:
            print("Map Segemtn Selected")
            mapView.isHidden = false
            tableView.isHidden = true
        case 1:
            print("List Segment Selected")
            mapView.isHidden = true
            tableView.isHidden = false
        default:
            break
        }
        
    }
    
    //change this to segue
    @objc func deleteBtnPressed(){
        self.view.layoutIfNeeded()
        let story = UIStoryboard(name: "Main", bundle: nil)
        let vc = story.instantiateViewController(withIdentifier: "AddOrEditLocationVC") as! AddOrEditLocationVC
        
        //        for i in 0..<self.coreList.count{
        //
        //            if let select = selectedPinView.title{
        //
        //                if let ant = select{
        //                    if(self.coreList[i].name ==  ant){
        //                        self.coreObj = self.coreList[i]
        //                        break
        //                    }
        //                }
        //            }
        //        }
        var selectedPerson:TPerson! = nil
        for i in 0..<self.filteredPersonLocationList.count{
            
            if let select = selectedPinView.title{
                
                if let ant = select{
                    if(self.filteredPersonLocationList[i].name ==  ant){
                        selectedPerson = self.filteredPersonLocationList[i]
                        break
                    }
                }
            }
        }
        vc.selectedPerson = selectedPerson
        //        vc.selectedLocEntity = coreObj
        vc.managedContext = ViewController.managedContext
        self.navigationController?.pushViewController(vc, animated: true)
        self.view.layoutIfNeeded()
        
    }
    
    func getLocIndexBasedOnTitle(title : String) -> Int {
        var i : Int = 0
        //        for loc in coreList {
        //
        //            if loc.name == title {
        //                return index
        //            }
        //            i += 1
        //        }
        for loc in filteredPersonLocationList {
            
            if loc.country == title {
                return index
            }
            i += 1
        }
        return -1
    }
    
}

class Artwork: NSObject, MKAnnotation {
    let title: String?
    let locationName: String
    let discipline: String
    let coordinate: CLLocationCoordinate2D
    let id:Int
    
    init(title: String, locationName: String, discipline: String, coordinate: CLLocationCoordinate2D,id:Int) {
        self.title = title
        self.locationName = locationName
        self.discipline = discipline
        self.coordinate = coordinate
        self.id  = id
        super.init()
    }
    
    var subtitle: String? {
        return locationName
    }
}
extension ViewController:UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.count > 0 {
            self.filteredPersonLocationList = self.personLocationList.filter { (person) -> Bool in
                return (person.country?.lowercased().contains(searchText.lowercased()) ?? true)
            }
        }else{
            self.filteredPersonLocationList = self.personLocationList
        }
        tableView.reloadData()
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        if searchBar.text!.count > 0{
            self.filteredPersonLocationList = self.personLocationList.filter { (person) -> Bool in
                return (person.country?.lowercased().contains(searchBar.text?.lowercased() ?? "") ?? true)
            }
        }else{
            self.filteredPersonLocationList = self.personLocationList
        }
        tableView.reloadData()
    }
}
