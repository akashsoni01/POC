//
//  TPerson+CoreDataProperties.swift
//  MyFirstMapTODO
//
//  Created by AkashBuzzyears on 1/24/20.
//  Copyright © 2020 lambton. All rights reserved.
//
//

import Foundation
import CoreData


extension TPerson {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<TPerson> {
        return NSFetchRequest<TPerson>(entityName: "TPerson")
    }

    @NSManaged public var birthday: Date?
    @NSManaged public var country: String?
    @NSManaged public var gender: String?
    @NSManaged public var lattiude: Double
    @NSManaged public var longitude: Double
    @NSManaged public var name: String?
    @NSManaged public var photoID: NSNumber?

}
