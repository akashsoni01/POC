//
//  TLocation+CoreDataClass.swift
//  Core Data Stack with location in swift
//
//  Created by AkashBuzzyears on 1/15/20.
//  Copyright © 2020 akash soni. All rights reserved.
//
//

import Foundation
import CoreData

@objc(TLocation)
public class TLocation: NSManagedObject {

}
