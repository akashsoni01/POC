import Foundation


public extension FileManager{
   static var documentUrl:URL {
        get {
            return try! FileManager.default.url(
                for: .documentDirectory,
                in: .userDomainMask,
                appropriateFor: nil,
                create: false)

        }
    }
}
