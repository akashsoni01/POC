//: Playground - noun: a place where people can play

import UIKit
//import Foundation
//print("hello world")
////for make document by
//FileManager.documentUrl
////file:///var/folders/r8/j76shv_n31jfnd_cn5hryjc80000gp/T/com.apple.dt.Xcode.pg/containers/com.apple.dt.playground.stub.iOS_Simulator.savingData-6FDA722F-755D-4592-AD4A-5D552AE0C6EE/Documents/
//URL(fileURLWithPath: "mystry", relativeTo: FileManager.documentUrl).path
////print(URL(fileURLWithPath: "mystry", relativeTo: FileManager.documentUrl).path)
//
//let fileUrl = FileManager.documentUrl.appendingPathComponent("string").appendingPathExtension("txt")
//print(FileManager.documentUrl.appendingPathComponent("string").appendingPathExtension("txt"))

let mystryDataInInt:[UInt8] = [234,234,23,56,32,234,34,32,43]
let mystryUrl = URL(fileURLWithPath: "mystry", relativeTo: FileManager.documentUrl)
let myData = Data(bytes: mystryDataInInt)
try myData.write(to: mystryUrl)
let savedData = try Data(contentsOf: mystryUrl)
savedData == myData
let savedDataInInt = Array(savedData)
mystryDataInInt == savedDataInInt

let emojiDataString = "❤️😀"
let emojiMystory = URL(fileURLWithPath: "emojiMystory", relativeTo: FileManager.documentUrl).appendingPathExtension("txt")
try! emojiDataString.write(to: emojiMystory, atomically: true, encoding: .utf8)
try String(contentsOf: emojiMystory)


let challengeDir = "F#"
let emojiMystory2 = URL(
    fileURLWithPath: challengeDir,
    relativeTo: FileManager.documentUrl)
    .appendingPathExtension("txt")

let challangeDataString = challengeDir.data(using: .utf8)
try! challangeDataString?.write(to: emojiMystory2, options: .atomic)
let savedDataformChalleng = try String(contentsOf: emojiMystory2)









