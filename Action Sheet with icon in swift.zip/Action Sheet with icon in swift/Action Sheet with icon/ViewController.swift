//
//  ViewController.swift
//  Action Sheet with icon
//
//  Created by AkashBuzzyears on 3/9/20.
//  Copyright © 2020 akash soni. All rights reserved.
//

//https://github.com/akashsoni01/POC




/////https://stackoverflow.com/questions/47370823/uialertaction-button-text-alignment-left


import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func actionSheetButtonTapped(_ sender:UIButton){
        let actionSheetAlertController: UIAlertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)

        let cancelActionButton = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        actionSheetAlertController.addAction(cancelActionButton)

        let cameraActionButton = UIAlertAction(title: "Camera", style: .default, handler: nil)
        actionSheetAlertController.addAction(cameraActionButton)
        cameraActionButton.setValue(UIImage(named: "camera")!.imageWithSize(scaledToSize: CGSize(width: 20, height: 20)), forKey: "image")
        cameraActionButton.setValue(CATextLayerAlignmentMode.left, forKey: "titleTextAlignment")
        
        let galleryActionButton = UIAlertAction(title: "Photo & Video Library", style: .default, handler: nil)
        actionSheetAlertController.addAction(galleryActionButton)
        galleryActionButton.setValue(UIImage(named: "gallery")!.imageWithSize(scaledToSize: CGSize(width: 20, height: 20)), forKey: "image")
        galleryActionButton.setValue(CATextLayerAlignmentMode.left, forKey: "titleTextAlignment")

        let documentsActionButton = UIAlertAction(title: "Documents", style: .default, handler: nil)
        actionSheetAlertController.addAction(documentsActionButton)
        documentsActionButton.setValue(UIImage(named: "documents")!.imageWithSize(scaledToSize: CGSize(width: 20, height: 20)), forKey: "image")
        documentsActionButton.setValue(CATextLayerAlignmentMode.left, forKey: "titleTextAlignment")
        
        let locationActionButton = UIAlertAction(title: "Location", style: .default, handler: nil)
        actionSheetAlertController.addAction(locationActionButton)
        locationActionButton.setValue(UIImage(named: "location")!.imageWithSize(scaledToSize: CGSize(width: 20, height: 20)), forKey: "image")
        locationActionButton.setValue(CATextLayerAlignmentMode.left, forKey: "titleTextAlignment")

        let contactActionButton = UIAlertAction(title: "Contact", style: .default, handler: nil)
        actionSheetAlertController.addAction(contactActionButton)
        contactActionButton.setValue(UIImage(named: "contact")!.imageWithSize(scaledToSize: CGSize(width: 20, height: 20)), forKey: "image")
        contactActionButton.setValue(CATextLayerAlignmentMode.left, forKey: "titleTextAlignment")

        self.present(actionSheetAlertController, animated: true, completion: nil)
        
        
        
    }
}

extension UIImage {

    func imageWithSize(scaledToSize newSize: CGSize) -> UIImage {

        UIGraphicsBeginImageContextWithOptions(newSize, false, 0.0)
        self.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
        let newImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return newImage
    }

}
