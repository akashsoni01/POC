import UIKit

let spaceSceneURL = Bundle.main.urls(forResourcesWithExtension: "png", subdirectory: "Scenes")![1]
spaceSceneURL.lastPathComponent

extension FileManager {

}

try FileManager.copyPNGSubdirectoriesToDocumentDirectory(subdirectoryNames: "Scenes", "Stickers")

FileManager.documentDirectoryURL


extension FileManager{
    static func getPngFileFormDirectory(subdirectoryName:String,pngFilename:String) -> UIImage?{
        
        return UIImage(contentsOfFile:
            FileManager.documentDirectoryURL.appendingPathComponent(subdirectoryName).appendingPathComponent(pngFilename).appendingPathExtension("png").path
        )
    }
}
