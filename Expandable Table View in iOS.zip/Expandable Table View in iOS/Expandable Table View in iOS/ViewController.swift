//
//  ViewController.swift
//  Expandable Table View in iOS
//
//  Created by Akash Soni on 26/11/19.
//  Copyright © 2019 Akash Soni. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tableView:UITableView!
    var sectionShouldShow = [Bool]()
    var arrayStrings = [["akash soni is a good boy. akash soni love apple. He is a great iOS developer. One day he dreamed to work for apple. and now he is on his way.","akash soni is a good boy. akash soni love apple. He is a great iOS developer. One day he dreamed to work for apple. and now he is on his way.","akash soni is a good boy. akash soni love apple. He is a great iOS developer. One day he dreamed to work for apple. and now he is on his way.","akash soni is a good boy. akash soni love apple. He is a great iOS developer. One day he dreamed to work for apple. and now he is on his way.","and now he is on his way.","and now he is on his way.and now he is on his way.","and now he is on his way.and now he is on his way.and now he is on his way."],["akash soni is a good boy. akash soni love apple. He is a great iOS developer. One day he dreamed to work for apple. and now he is on his way.","akash soni is a good boy. akash soni love apple. He is a great iOS developer. One day he dreamed to work for apple. and now he is on his way.","akash soni is a good boy. akash soni love apple. He is a great iOS developer. One day he dreamed to work for apple. and now he is on his way.","akash soni is a good boy. akash soni love apple. He is a great iOS developer. One day he dreamed to work for apple. and now he is on his way.","and now he is on his way.","and now he is on his way.and now he is on his way.","and now he is on his way.and now he is on his way.and now he is on his way."],["akash soni is a good boy. akash soni love apple. He is a great iOS developer. One day he dreamed to work for apple. and now he is on his way.","akash soni is a good boy. akash soni love apple. He is a great iOS developer. One day he dreamed to work for apple. and now he is on his way.","akash soni is a good boy. akash soni love apple. He is a great iOS developer. One day he dreamed to work for apple. and now he is on his way.","akash soni is a good boy. akash soni love apple. He is a great iOS developer. One day he dreamed to work for apple. and now he is on his way.","and now he is on his way.","and now he is on his way.and now he is on his way.","and now he is on his way.and now he is on his way.and now he is on his way."]]

    override func viewDidLoad() {
        super.viewDidLoad()
        sectionShouldShow = Array(repeating: false, count: arrayStrings.count)
        // Do any additional setup after loading the view.
    }


}

extension ViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = Bundle.main.loadNibNamed("HeaderView", owner: self, options: nil)?.first as! HeaderView
        
        view.leftLabel.text = "Left\(section)"
        view.rightButton.isHidden = false
        view.section = section
        view.delegate = self
        view.rightButton.setTitle("right", for: .normal)
        
        return view    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrayStrings.count
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Section Header \(section)"
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sectionShouldShow[section] ? arrayStrings[section].count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = arrayStrings[indexPath.section][indexPath.row]
        cell?.backgroundColor = UIColor.random
        return cell!

    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("section tapped\(indexPath)")
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.transform = CGAffineTransform(translationX: tableView.bounds.width, y: -50)

               UIView.animate(
                withDuration: 0.2,
                delay: 0.1 * Double(indexPath.row),
                   options: [.curveEaseInOut],
                   animations: {
                       cell.transform = CGAffineTransform(translationX: 0, y: 0)
               })
           }
    
}
extension ViewController:UITableviewSectionTapableDelegate{
    func didSelectSection(at section: Int) {
        for i in 0..<sectionShouldShow.count{
            sectionShouldShow[i] = (i == section ? true : false)
        }
        tableView.reloadData()
    }
    
}

extension UIColor {
    static var random: UIColor {
        return UIColor(red: .random(in: 0...1),
                       green: .random(in: 0...1),
                       blue: .random(in: 0...1),
                       alpha: 1.0)
    }
}
