//
//  HeaderTableViewCell.swift
//  MHC SHOP
//
//  Created by MHBE Developer on 14/10/19.
//  Copyright © 2019 MHC. All rights reserved.
//

import UIKit
@objc protocol UITableviewSectionTapableDelegate{
    @objc optional func didSelectSection(at section:Int)
}

class HeaderView: UITableViewCell {
    var delegate:UITableviewSectionTapableDelegate!
    
    @IBOutlet weak var leftLabel: UILabel!
    @IBOutlet weak var rightButton: UIButton!
    var section:Int?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        let gesture = UITapGestureRecognizer()
        gesture.addTarget(self, action: #selector(buttonTapped(_:)))
        self.contentView.addGestureRecognizer(gesture)
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func buttonTapped(_ sender: UIButton) {
        delegate.didSelectSection!(at: section!)
    }
    
}
