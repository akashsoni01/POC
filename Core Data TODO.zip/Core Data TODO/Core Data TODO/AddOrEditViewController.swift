//
//  AddOrEditViewController.swift
//  Core Data TODO
//
//  Created by AkashBuzzyears on 1/11/20.
//  Copyright © 2020 akash soni. All rights reserved.
//

import UIKit

class AddOrEditViewController: UIViewController {
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var age: UITextField!
    @IBOutlet weak var tuition: UITextField!
    @IBOutlet weak var date: UITextField!
    var user:TUser!
    private let appDelegate = UIApplication.shared.delegate as! AppDelegate
    private let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func saveButtonAction(_ sender: UIButton) {
        // create or update code
        if user == nil{
            let user = TUser(context: context)
            user.name = name.text
            user.age = 0
            user.tuition = 9.0
            user.startDate = Date()
            appDelegate.saveContext()
        }else{
            self.user.name = name.text
            self.user.age = 0
            self.user.tuition = 9.0
            self.user.startDate = Date()
            appDelegate.saveContext()
        }
    }
}
