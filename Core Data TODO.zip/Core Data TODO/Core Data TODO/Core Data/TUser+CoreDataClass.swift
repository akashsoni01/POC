//
//  TUser+CoreDataClass.swift
//  Core Data TODO
//
//  Created by AkashBuzzyears on 1/11/20.
//  Copyright © 2020 akash soni. All rights reserved.
//
//

import Foundation
import CoreData

@objc(TUser)
public class TUser: NSManagedObject {

}
