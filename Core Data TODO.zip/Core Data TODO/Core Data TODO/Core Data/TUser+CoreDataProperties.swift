//
//  TUser+CoreDataProperties.swift
//  Core Data TODO
//
//  Created by AkashBuzzyears on 1/11/20.
//  Copyright © 2020 akash soni. All rights reserved.
//
//

import Foundation
import CoreData


extension TUser {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<TUser> {
        return NSFetchRequest<TUser>(entityName: "TUser")
    }

    @NSManaged public var name: String?
    @NSManaged public var age: Int16
    @NSManaged public var tuition: Double
    @NSManaged public var startDate: Date?

}
