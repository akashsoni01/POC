//
//  ViewController.swift
//  Core Data TODO
//
//  Created by AkashBuzzyears on 1/11/20.
//  Copyright © 2020 akash soni. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController, UITableViewDelegate,UITableViewDataSource{
    @IBOutlet weak var tableView:UITableView!
    var users = [TUser]()
    private let appDelegate = UIApplication.shared.delegate as! AppDelegate
    private let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    let refresh = UIRefreshControl()
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.refreshControl = refresh
        refresh.addTarget(self, action: #selector(fetchUser), for: .valueChanged)
        fetchUser()
    }
    @objc func fetchUser(){
        let request:NSFetchRequest<TUser> = TUser.fetchRequest()
        self.users = (try? context.fetch(request)) ?? [TUser]()
        refresh.endRefreshing()
        self.tableView.reloadData()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = users[indexPath.row].name
        return cell
    }
    
    
    @IBAction func addButtonTapped(){
        
    }
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let story = UIStoryboard(name: "Main", bundle: nil)
        let vc = story.instantiateViewController(identifier: "AddOrEditViewController") as! AddOrEditViewController
        vc.user = users[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)

    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        switch editingStyle {
        case .delete:
            context.delete(users[indexPath.row])
            users.remove(at: indexPath.row)
            self.tableView.deleteRows(at: [indexPath], with: .bottom)
            appDelegate.saveContext()
            break
        default:
            break
        }
    }
}

