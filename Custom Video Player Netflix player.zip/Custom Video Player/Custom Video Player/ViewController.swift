//
//  ViewController.swift
//  Custom Video Player
//
//  Created by Akash soni on 07/09/21.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

