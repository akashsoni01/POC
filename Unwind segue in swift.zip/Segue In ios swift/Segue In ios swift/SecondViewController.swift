//
//  SecondViewController.swift
//  Segue In ios swift
//
//  Created by Akash Soni on 03/09/19.
//  Copyright © 2019 Akash Soni. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    @IBOutlet weak var textField:UITextField!
    var string:String?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
     MARK: - Navigation

     In a storyboard-based application, you will often want to do a little preparation before navigation

    */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.string = textField?.text
    }

}
