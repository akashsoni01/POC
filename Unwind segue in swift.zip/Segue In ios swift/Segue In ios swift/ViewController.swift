//
//  ViewController.swift
//  Segue In ios swift
//
//  Created by Akash Soni on 03/09/19.
//  Copyright © 2019 Akash Soni. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func unwindAction(_ sender: UIStoryboardSegue) {
        if sender.source is SecondViewController{
            if let vc = sender.source as? SecondViewController{
                label.text = vc.string
            }
        }
        
    }
    
}

