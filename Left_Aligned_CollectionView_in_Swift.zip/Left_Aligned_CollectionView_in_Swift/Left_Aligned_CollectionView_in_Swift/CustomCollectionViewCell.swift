//
//  CustomCollectionViewCell.swift
//  Left_Aligned_CollectionView_in_Swift
//
//  Created by Akash Soni on 13/11/19.
//  Copyright © 2019 Akash Soni. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var label:UILabel!
}
