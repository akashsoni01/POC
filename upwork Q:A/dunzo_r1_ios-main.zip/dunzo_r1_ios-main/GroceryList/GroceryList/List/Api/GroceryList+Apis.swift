//
//  Apis.swift
//  GroceryList
//
//  Created by Akash soni on 10/10/22.
//

import Foundation

internal struct Apis {
    internal static func getGroceryList() -> [GroceryProduct] {
        let path = Bundle.main.path(forResource: "ProductList", ofType: "json")
        let data = try! NSData(contentsOfFile: path!, options: NSData.ReadingOptions.mappedIfSafe) as Data
        guard let data = try? JSONDecoder().decode(GroceryListModel.self, from: data) else  { return [] }

        return data.items.product_list
        
    }
    
    internal static func getGroceryList(complitionHandler: @escaping Constants.serviceCompletion) {
        let url = Constants.baseUrl + "/posts"
        let request = DataTaskHandler()
        request.handler = complitionHandler
        request.fetchAsyncData(urlPath: url, dataToServer: Data(), params: [:], method: "GET")

        
    }
}
