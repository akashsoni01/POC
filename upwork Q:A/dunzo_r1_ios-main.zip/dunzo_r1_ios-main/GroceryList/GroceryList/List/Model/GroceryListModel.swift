//
//  GroceryListModel.swift
//  GroceryList
//
//  Created by Akash soni on 10/10/22.
//

import Foundation


struct GroceryListModel: Codable {
    let items: GroceryModel
}

struct GroceryModel: Codable {
    let total: Int
    let product_list: [GroceryProduct]
}

struct GroceryProduct: Codable {
    let id: String
    let title: String
    let quantity: String
    let image_url: String
    let original_price: String
    let offer_price: String?
    let discount_percentage: String?
}
