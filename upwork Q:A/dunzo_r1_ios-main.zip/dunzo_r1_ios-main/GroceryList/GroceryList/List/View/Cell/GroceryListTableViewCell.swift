//
//  GroceryListTableViewCell.swift
//  GroceryList
//
//  Created by Akash soni on 10/10/22.
//

import UIKit

class GroceryListTableViewCell: UITableViewCell {

    @IBOutlet weak var groceryImageView: UIImageView!
    @IBOutlet weak var groceryTitleLabel: UILabel!
    @IBOutlet weak var groceryWeightLabel: UILabel!
    @IBOutlet weak var groceryPriceLabel: UILabel!

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    internal func setupCell(cellData: GroceryProduct) {
        groceryImageView.downloadImage(urlString: cellData.image_url)
        groceryImageView.contentMode = .scaleToFill
        groceryTitleLabel.text = cellData.title
        groceryWeightLabel.text = cellData.quantity
        groceryPriceLabel.text = cellData.original_price
        
        groceryImageView.layer.borderColor = UIColor.lightGray.cgColor
        groceryImageView.layer.borderWidth = 1
        groceryImageView.layer.cornerRadius = 5


    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
