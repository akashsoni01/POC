//
//  GroceryListViewController.swift
//  GroceryList
//
//  Created by Akash soni on 10/10/22.
//

import UIKit

class GroceryListViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    private var list = [GroceryProduct]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
    }
    
    private func setupUI() {
        // after api call
//        Apis.getGroceryList { data, response, err in
//            if err != nil {
//                // show alert
//            } else if (response as? HTTPURLResponse)?.statusCode == 200 {
//                DispatchQueue.main.async { [weak self] in
//                    if let data = data {
//                        let model = try? JSONDecoder().decode(GroceryListModel.self, from: data)
//                        self?.list = model?.items.product_list ?? []
//
//                    }
//
//                }
//            } else {
//                // show some error
//            }
//
//        }
        
        self.list = Apis.getGroceryList()
        self.tableView.reloadData()
    }

}

extension GroceryListViewController: UITableViewDelegate, UITableViewDataSource {
    internal func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "GroceryListTableViewCell") as! GroceryListTableViewCell
        cell.setupCell(cellData: list[indexPath.row])
        return cell
    }
    
    
}
