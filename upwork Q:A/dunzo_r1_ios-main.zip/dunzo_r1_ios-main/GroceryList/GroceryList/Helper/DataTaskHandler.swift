//
//  DataTaskHandler.swift
//  GroceryList
//
//  Created by Akash soni on 10/10/22.
//

import Foundation

class DataTaskHandler {
    var handler : Constants.serviceCompletion?
    var urlpath:URL?
    var request:URLRequest?
    
    func fetchAsyncData(urlPath : String, dataToServer : Data, params:Dictionary<String, Any> , method: String = "GET", isPublic:Bool = false,header:[String:String] = [:])
    {
        let headerDict = header
        request = URLRequest(url: URL(string: urlPath)!, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 60.0)
        request?.httpMethod = method
        request?.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        switch method {
        case "GET":
            if !params.isEmpty {
                var urlComp = URLComponents(string: urlPath)!
                var items = [URLQueryItem]()
                
                for (key,value) in params {
                    items.append(URLQueryItem(name: key, value: value as? String))
                }
                
                items = items.filter{!$0.name.isEmpty}
                
                if !items.isEmpty {
                    urlComp.queryItems = items
                }
                urlpath =  urlComp.url
                request?.url = urlpath
            }
        case "POST", "PUT":
            request?.httpBody = dataToServer
        default:
            break
        }
        
        request?.allHTTPHeaderFields = headerDict
        
        debugPrint("URL \(urlPath)")
        debugPrint("Headers \(request?.allHTTPHeaderFields?.description ?? "No Header")")
        if let debugData = request?.httpBody{
            debugPrint("Request Body \(debugData.prettyJson ?? "No Body")")
        }
        let configuration = URLSessionConfiguration.default
        let task = URLSession(configuration: configuration).dataTask(with: request!) { (data, response, error) in
            if let httpResponse = response as? HTTPURLResponse {
                    print(httpResponse.statusCode,"<--------CODE")
                }
          
            DispatchQueue.main.async {
                self.handler?(data, response, error)
            }
            if let debugData = data{
                debugPrint("Response Body \(debugData.prettyJson ?? "No Body")")
            }
        }
        task.resume()
    }
    
}

extension Data {
    var prettyJson: String? {
        guard let object = try? JSONSerialization.jsonObject(with: self, options: []),
            let data = try? JSONSerialization.data(withJSONObject: object, options: [.prettyPrinted]),
            let prettyPrintedString = String(data: data, encoding:.utf8) else { return nil }
        
        return prettyPrintedString
    }
}
