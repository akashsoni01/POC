//
//  Constants.swift
//  GroceryList
//
//  Created by Akash soni on 10/10/22.
//

import Foundation

struct Constants {
    static let imageCache = NSCache<AnyObject, AnyObject>()
    
    typealias serviceCompletion = (_ data:Data?,_ response: URLResponse?,_ err: Error?) -> Void
      static var baseUrl: String { return "https://jsonplaceholder.typicode.com"
          
          
      }

}
