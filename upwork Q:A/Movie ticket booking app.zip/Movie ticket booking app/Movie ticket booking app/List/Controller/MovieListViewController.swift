//
//  MovieListViewController.swift
//  Movie ticket booking app
//
//  Created by Akash soni on 08/11/22.
//

import UIKit

class MovieListViewController: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    private var movieList = [Movie]()
    private var geners = [String]()
    private var ratings = [Rating]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchData()
     }
    
    private func fetchData() {
        APIs.fetchApi(urlString: Constants.baseURL + "93521f33e6665b47137c") { [weak self] movieData in
            guard let self = self else { return }
            
            self.movieList = movieData?.movies ?? []
            self.geners = movieData?.genres ?? []
            self.fetchRatings()
        }

    }
    
    @IBAction func filterTapped(_ sender: UIBarButtonItem) {
        // bottom sheet - 1. gener , 2. rating = acen and decen
        showSheetOfSorting()
        
    }
    
    private func showSheetOfSorting() {
        var sheet = UIAlertController(title: "Sort", message: "", preferredStyle: .actionSheet)

        let ratingAction = UIAlertAction(title: "Ratings", style: .default) { action in
            self.showRatings()
        }
        
        let generAction = UIAlertAction(title: "Geners", style: .default) { action in
            self.showGener()
        }
        
        sheet.addAction(ratingAction)
        sheet.addAction(generAction)
        
        self.present(sheet, animated: true)

    }
    
    private func showRatings() {
        var sheet = UIAlertController(title: "Rating", message: "", preferredStyle: .actionSheet)

        let ase = UIAlertAction(title: "Asending", style: .default) { action in
            self.sortAsc()
        }
        
        let dse = UIAlertAction(title: "Decending", style: .default) { action in
            self.sortDec()
        }
        
        sheet.addAction(ase)
        sheet.addAction(dse)
        
        self.present(sheet, animated: true)

    }
    
    private func showGener() {
        var sheet = UIAlertController(title: "Gener", message: "", preferredStyle: .actionSheet)
        
        let ase = UIAlertAction(title: "Asending", style: .default) { action in
            
        }
        
        let dse = UIAlertAction(title: "Decending", style: .default) { action in
            
        }
        let actionComedy = UIAlertAction(title: "Comedy", style: .default)
        { action in
            
        }
        let actionFantasy = UIAlertAction(title: "Fantasy", style: .default){ action in
            
        }
        
        
        sheet.addAction(ase)
        sheet.addAction(dse)
        
        self.present(sheet, animated: true)

    }

    private func sortAsc() {
        self.movieList = movieList.sorted(by: { $0.ratingDouble > $1.ratingDouble })
        self.collectionView.reloadData()
    }
    
    private func sortDec() {
        self.movieList = movieList.sorted(by: { $0.ratingDouble < $1.ratingDouble })
        self.collectionView.reloadData()

    }
    
    private func fetchRatings() {
        APIs.fetchRatings(urlString: Constants.baseURL + "3f07f86370e2f122234c") { ratings in
            for i in 0 ..< self.movieList.count {
                guard let ratings = ratings else { return }
                let rating = ratings.filter({ rating in
                    return self.movieList[i].id == rating.id
                }).first?.rating ?? 0.0
                self.movieList[i].rating = String(format: "Rating: %.2f", rating)
                self.movieList[i].ratingDouble = rating
            }
            
            DispatchQueue.main.async {
                self.collectionView.reloadData()
            }
        }
    }
}

extension MovieListViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movieList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MovieListCollectionViewCell", for: indexPath) as! MovieListCollectionViewCell
        let movie = self.movieList[indexPath.row]
        cell.setupView(movie: movie)
        return cell
        
    }
    
    
}
