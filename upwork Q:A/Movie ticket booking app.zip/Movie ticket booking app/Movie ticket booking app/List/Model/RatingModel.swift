//
//  RatingModel.swift
//  Movie ticket booking app
//
//  Created by Akash soni on 08/11/22.
//

import Foundation


struct Rating: Codable {
    let id: Int
    let title: String
    let rating: Double
}

typealias Ratings = [Rating]
