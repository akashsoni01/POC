//
//  MovieListModel.swift
//  Movie ticket booking app
//
//  Created by Akash soni on 08/11/22.
//

import Foundation

struct MovieData: Decodable {
    let genres: [String]
    var movies: [Movie]
}

// MARK: - Movie
struct Movie: Decodable {
    let id: Int
    let title, year, runtime: String
    let genres: [String]
    let director, actors, plot: String
    let posterURL: String
    var rating: String?
    var ratingDouble: Double = 0.0

    enum CodingKeys: String, CodingKey {
        case id, title, year, runtime, genres, director, actors, plot
        case posterURL = "posterUrl"
    }
}
