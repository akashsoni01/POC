//
//  MovieListCollectionViewCell.swift
//  Movie ticket booking app
//
//  Created by Akash soni on 08/11/22.
//

import UIKit

class MovieListCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var movieTitleLabel: UILabel!
    @IBOutlet weak var movieRatingLabel: UILabel!
    var movie: Movie?
    
    func setupView(movie: Movie) {
        self.movie = movie
        imageView.downloadImage(urlString: movie.posterURL)
        movieTitleLabel.text = movie.title
        /// call api for ratings
        if let rating = movie.rating {
            movieRatingLabel.text = rating
        } else {
            movieRatingLabel.text = "Rating: _._"
        }
        
    }
    
}
