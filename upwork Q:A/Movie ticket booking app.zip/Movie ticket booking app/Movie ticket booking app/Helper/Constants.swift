//
//  Constants.swift
//  Movie ticket booking app
//
//  Created by Akash soni on 08/11/22.
//


import UIKit

struct Constants {
    typealias movieListComplition = (_ :MovieData?) -> Void
    typealias ratingComplition = (_ :Ratings?) -> Void
    static let baseURL = "https://api.npoint.io/"
    static var imageCache = NSCache<AnyObject, AnyObject>()
}

