//
//  ViewController.swift
//  ScrollView with content view in swift
//
//  Created by AkashBuzzyears on 5/14/20.
//  Copyright © 2020 akash soni. All rights reserved.
//


//lrtb scroll view to super view 0
//content view 0,0,0,0 with hieght and width equals to View(super to super view)
//view's height constraint priorty equals to 250
//create your view in such a way so that content view can adjust it's size accordingly
//like you do in autoresizable cell or copy past this controller to your storyboard
//you can make your viewcontroller free form after these steps for better visiblity

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

